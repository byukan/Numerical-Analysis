function [ftw] = f(ti, wi, argf)
%f is the function handle which defines the f(t,y) in the IVP using this
%format
ftw =ti*exp(3*ti) - 2*wi;  %equation of exercise 5.4.1a from the book
end
