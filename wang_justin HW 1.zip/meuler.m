function [wc] = meuler(ti, wi, h, f, argf)
%implements modified Euler's method
wc=wi+(h/2)*(f(ti,wi,argf)+f((ti+h),wi+h*f(ti,wi,argf),argf));
end