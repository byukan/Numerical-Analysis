function [ftw] = f2d(ti,wi,argf)
%f is the function handle which defines the f(t,y) in the IVP using this
%format
ftw= (ti^-2)*(sin(2*ti)-(2*ti*wi));  %equation of exercise 5.4.2d from the book
end
