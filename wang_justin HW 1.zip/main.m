%script main.m solves IVPs in the two exercises by using the 3 methods, and
%plots the approximated solutiosn versus the actual ones.
a_1 = 0; %starting point a
b_1 = 1; %end point b
y0_1 = 0; %initial condition y0
N = 100; %set 100 steps so the graph is resonably smooth-looking
argf=[]; %empty

%for exercise 5.4.2d
a_2 = 1;%starting point a
b_2 = 2;%end point b
y0_2 = 2;%initial condition y0

%the following just uses odesolver using the three methods for each
%exercise 1, and 2
euler1 = odesolver(a_1,b_1,y0_1,N,@f1a,argf,'euler');
mid1 = odesolver(a_1,b_1,y0_1,N,@f1a,argf,'midpoint');
modeul1 = odesolver(a_1,b_1,y0_1,N,@f1a,argf,'meuler');

euler2 = odesolver(a_2,b_2,y0_2,N,@f2d,argf,'euler');
mid2 = odesolver(a_2,b_2,y0_2,N,@f2d,argf,'midpoint');
modeul2 = odesolver(a_2,b_2,y0_2,N,@f2d,argf,'meuler');

for i=1:N  %loop for each step, the step size is N, we use 100
    t1(i) = a_1+i*((b_1-a_1)/N); %approximate method solution
    t2(i) = a_2+i*((b_2-a_2)/N);
    
   %actual solution given in teh text
    y1(i) = (1/5)*t1(i)*exp(3*t1(i))-(1/25)*exp(3*t1(i))+(1/25)*exp(-2*t1(i));
    y2(i) = 1/2*(t2(i)^(-2))*(4+cos(2)-cos(2*t2(i)));
end
    
    
for i=1:N  %Now loop for each iteration for the error values
    %the error for method compared to actual
    %solution, d stands for difference
    d1_e(i) = abs(euler1(i)-y1(i)); %exercise 1 Euler
    d1_mid(i) = abs(mid1(i)-y1(i));%exercise 1 Midpoint
    d1_m(i) = abs(modeul1(i)-y1(i));%exercise 1 Modified Euler
    
    d2_e(i) = abs(euler2(i)-y2(i));  %exercise 2 Euler
    d2_mid(i) = abs(mid2(i)-y2(i));  %exercise 2 Midpoint
    d2_m(i) = abs(modeul2(i)-y2(i));  %exercise 2 Modified Euler
end



%there will be 12 figures total for all the exercises and methods
figure(1);

plot(t1,euler1,'-g',t1,y1,'-r');
title('f1 approx. vs real solution, Euler Method for exercise 5.4.1a');
xlabel('Time (seconds)');
ylabel('Approximation vs Real Solution');

figure(2);

plot(t1,d1_e,'-');
title('f1 error using Euler Method for 5.4.1a');
xlabel('t');
ylabel('error');

figure(3);

plot(t1,mid1,'-g',t1,y1,'-r');
title('f1 approx. & real solution using Midpoint Method for 5.4.1a');
xlabel('Time (seconds)');
ylabel('Approximation method vs Real Solution');

figure(4);

plot(t1,d1_mid,'-');
title('f1 error using Midpoint Method for 5.4.1a');
xlabel('t');
ylabel('error');

figure(5);

plot(t1,modeul1,'-g',t1,y1,'-r');
title('f1 approx. vs real solution for Modified euler Method for 5.4.1a');
xlabel('Time (seconds)');
ylabel('Approximation vs Real Solution');

figure(6);

plot(t1,d1_m,'-');
title('f1 error using Modified euler Method for 5.4.1a');
xlabel('t');
ylabel('error');

figure(7);

plot(t2,euler2,'-g',t2,y2,'-r');
title('f1 approx. vs real solution using Euler Method for 5.4.2d');
xlabel('Time (seconds)');
ylabel('Approximation v Real Solution');

figure(8);

plot(t2,d2_e,'-');
title('f1 error using Euler Method , 5.4.2d');
xlabel('t');
ylabel('error');

figure(9);

plot(t2,mid2,'-g',t2,y2,'-r');
title('f1 approx. vs real solution using Midpoint Method for 5.4.2d');
xlabel('Time (seconds)');
ylabel('Approximation vs Real Solution');

figure(10);

plot(t2,d2_mid,'-');
title('f1 error using Midpoint Method , 5.4.2d');
xlabel('t');
ylabel('error');

figure(11);

plot(t2,modeul2,'-g',t2,y2,'-r');
title('f1 approx. v real solution using mod euler Method, 5.4.2d');
xlabel('Time (seconds)');
ylabel('Approximation & Real Solution');

figure(12);

plot(t2,d2_m,'-');
title('f1 error using mod euler Method for 5.4.2d');
xlabel('t');
ylabel('error');






