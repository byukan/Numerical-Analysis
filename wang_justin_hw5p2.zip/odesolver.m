function [ yt ] = odesolver( a, b, y0, h, fun, argf, hoption)
%This function solves the system of first-order IVPs using one-step methods 
%or multistep methods, including at least the midpoint method and the Runge-Kutta 
%method of order four.  Define two nested functions rk4 and midpoint in this routine. 
%Therefore, either �rk4� or �midpoint� will be option.
%Inputs:
%a is the initial time
%b is the final time
%y0 is the initial condition
%h is the step size
%f is the function the defines the IVP
%argf contains related parameters for f, which is optional
%hoption can specify 'rk4' , and 'midpoint'
%Outputs:
%yt is the approximated solution to the initial value problem

switch hoption
    case 'rk4'
    x=y0;
    
    b=-h.*fun.F(x);
    
    N=1/h;
    for i=1:N  ;  %step 2, do steps 3-7
        
    A=fun.J(x);
    k1=A\b;  %solve the linear system A*k1=b
    A=fun.J(x+.5.*k1);
    k2=A\b;
    A=fun.J(x+.5.*k2);
    k3=A\b;
    A=fun.J(x+k3);
    k4=A\b;

    x=x+(k1+2*k2+2*k3+k4)./6;

    yt=x;
    
    end
    
    case 'midpoint'
        N = 1/h;
        b = -h* fun.F(y0);
        x= y0;
        for k=1:N
            A = fun.J(x);
            f = A\b;
            t = x+0.5*f;
            A = fun.J(t);
            x=x+A\b;
        end
        yt=x;
 end 
 
 
end