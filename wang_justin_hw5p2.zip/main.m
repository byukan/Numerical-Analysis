format long
%solves the nonlinear problems specified in "solutions"
fun.F = @(x)[15*x(1)+x(2)^2-4*x(3)-13 ; x(1)^2+10*x(2)-x(3)-11 ; x(2)^3-25*x(3)+22];
fun.J = @(x) [15 2*x(2) -4 ; 2*x(1) 10 -1; 0 2*x(2)^2 -25];
paras.tol=10^-6;
paras.maxiter=10;

%Exercise 10.2.6c
paras.option='newton';
[ newton_x, newton_iter, newton_runtime ]=fsolver( [0;0;0], fun, paras )
%Exercise 10.3.5c
paras.option='broyden';
[ broyden_x, broyden_iter, broyden_runtime ] = fsolver( [0;0;0], fun, paras )
%Exercise 10.4.2a
paras.option='steep';
[ steep_x, steep_iter, steep_runtime ] =fsolver( [0;0;0], fun, paras )
%Exercise 10.5.4c
paras.option='homotopy';
paras.hoption='rk4';
[ homotopy_x, homotopy_iter, homotopy_runtime ]=fsolver( [0;0;0], fun, paras )


paras.hoption='midpoint';
[ homotopy_x, homotopy_iter, homotopy_runtime ]=fsolver( [0;0;0], fun, paras )


%Actual Solution
paras.option='newton';
paras.tol=eps;  %epsilon
[ actual_x, actual_iter, actual_runtime ]=fsolver( [0;0;0], fun, paras )


%Error
error_newton=norm( newton_x-actual_x  ,Inf)
error_broyden=norm( broyden_x-actual_x  ,Inf)
error_steep=norm( steep_x-actual_x  ,Inf)
error_homotopy=norm( homotopy_x-actual_x  ,Inf)








%odesolver( 0, 1, [0;0;0], 1/10, fun, [], 'rk4')