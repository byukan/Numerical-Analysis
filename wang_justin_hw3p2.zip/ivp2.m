function f2 = ivp2(ti,wi)
%exercise 5.11.2b with h=.1 and .2

 f2 = -10.*wi+10.*ti+1;

end