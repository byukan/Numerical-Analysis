function [ f1 ] = ivp1( ti, wi )
%exercise 5.6.2d, first initial value problem

f1=(-1).*ti.*wi+4.*ti./wi;

end